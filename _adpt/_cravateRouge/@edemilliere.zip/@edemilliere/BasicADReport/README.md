# BasicADReport
This is a basic Active Directory report that can be used to generate a quick overview of an Active Directory domain.
```PowerShell
.\BasicADReport.ps1 -DomainName D2K12R2.local
```
This will generate an HTML file in the current directory and open it with the default web browser you set.
