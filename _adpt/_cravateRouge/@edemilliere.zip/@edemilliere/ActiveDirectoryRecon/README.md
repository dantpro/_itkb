# ActiveDirectoryRecon
PowerShell module for Active Directory Recon

The functions in this module won't require the ActiveDirectory module from the Active Directory RSAT, this will be based on .Net and LDAP. They mostly will be PowerShell v2 compatible.
