---
layout: post
title:  "Offphish - Phishing revisited in 2023"
date:   2023-02-09 10:00:00 +0200
abstract: "What is the state of the art with phishing in 2023? What techniques do exist, which do still work and what is know-how worth revisiting?..."
tags: RedTeaming
---

*I've published this blog post on my employeer's blog. This entry is used just to align and keep track of the chronicle.*

Read the blog post here:

> **[https://www.securesystems.de/blog/offphish-phishing-revisited-in-2023/](https://www.securesystems.de/blog/offphish-phishing-revisited-in-2023/)**